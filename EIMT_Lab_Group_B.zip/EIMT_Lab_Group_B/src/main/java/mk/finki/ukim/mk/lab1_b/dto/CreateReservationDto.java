package mk.finki.ukim.mk.lab1_b.dto;

public record CreateReservationDto (String username, Long accommodationId){
}
