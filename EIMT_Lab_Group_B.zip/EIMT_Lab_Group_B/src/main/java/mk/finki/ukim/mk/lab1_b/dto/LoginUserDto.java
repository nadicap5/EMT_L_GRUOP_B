package mk.finki.ukim.mk.lab1_b.dto;

public record LoginUserDto(String username, String password) {
}

