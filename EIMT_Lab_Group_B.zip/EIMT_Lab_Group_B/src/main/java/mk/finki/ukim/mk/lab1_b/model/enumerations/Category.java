package mk.finki.ukim.mk.lab1_b.model.enumerations;

public enum Category {
    ROOM,
    HOUSE,
    FLAT,
    APARTMENT,
    HOTEL,
    MOTEL
}
